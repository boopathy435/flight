package com.flightcheckin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightcheckinApplicationTests {

	@Test
	void contextLoads() {
	}

}
