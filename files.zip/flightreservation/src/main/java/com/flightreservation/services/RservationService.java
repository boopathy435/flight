package com.flightreservation.services;

import com.flightreservation.dto.ReservationRequest;
import com.flightreservation.model.Reservation;

public interface RservationService {

	public Reservation bookFlight(ReservationRequest request);
}
